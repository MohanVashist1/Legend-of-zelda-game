import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bat extends Enemy
{
    /**
     * Act - do whatever the bat wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    GifImage gifImage = new GifImage("bat.gif");
    private   int RandomNumber=((int)(Math.random()*4));
    private int timerUp=20;
    private int check;
    public bat()
    {
        check = 0;
    }
    public void act() 
    {
        setImage(gifImage.getCurrentImage());

        
        if(RandomNumber==0){//moves down
            setLocation(getX(), getY() + 4);
            checkM1();;// checks to see if its touching any walls,if it is touching check will not equal zero, thus it will not move
            checkM2();
            checkM3();
            checkM7();
            checkM8();
            checkM9();
            checkM10();
            checkD1();
            if(isTouching(StatusBar.class))
            {
                check++;
            }
            setLocation(getX(), getY() - 4);
            if(check == 0)
            {
                setLocation(getX(), getY() + 3);
            }
            check = 0;

        }
        if(RandomNumber==1){
            setLocation(getX(), getY()- 4 );
            checkM1();;// checks to see if its touching any walls,if it is touching check will not equal zero, thus it will not move
            checkM2();
            checkM3();
            checkM7();
            checkM8();
            checkM9();
            checkM10();
            checkD1();
            if(isTouching(StatusBar.class))
            {
                check++;
            }
            setLocation(getX(), getY() + 4);
            if(check == 0)
            {
                setLocation(getX(), getY() -3);
            }
            check = 0;
            //moves up
        }
        if(RandomNumber==2){
            setLocation(getX()+ 4, getY() );
            checkM1();;// checks to see if its touching any walls,if it is touching check will not equal zero, thus it will not move
            checkM2();
            checkM3();
            checkM7();
            checkM8();
            checkM9();
            checkM10();
            checkD1();
            if(isTouching(StatusBar.class))
            {
                check++;
            }
            setLocation(getX()- 4, getY() );
            if(check == 0)
            {
                setLocation(getX() +3, getY());
            }
            check = 0;
            //moves right
        }
        if(RandomNumber==3){
            setLocation(getX()- 4, getY());
            checkM1();// checks to see if its touching any walls,if it is touching check will not equal zero, thus it will not move
            checkM2();
            checkM3();
            checkM7();
            checkM8();
            checkM9();
            checkM10();
            checkD1();
            if(isTouching(StatusBar.class))
            {
                check++;
            }
            setLocation(getX() + 4, getY() );
            if(check == 0)
            {
                setLocation(getX() -3, getY() );
            }
            check = 0;
            
            //moves left
        }
        if (timerUp>0)
        {

            timerUp--;
            if(timerUp == 0) {

                RandomNumber=((int)(Math.random()*4));
                timerUp=15;

            }

        }    
        heart();
    }

    public void heart(){
        if(Greenfoot.isKeyDown("a")){//checks to see if key is down and is touching link which means its dead, then drops a heart, it also drops a heart if it touches the sword
            if(isTouching(link.class)){
                int heart=((int)(Math.random()*6));
                if(heart==0){
                    getWorld().addObject(new heart(),getX(),getY());
                }
            }
        }
        else if(isTouching(sword.class)){// if touching the sword check random number for herat and then remove the object
            int heart=((int)(Math.random()*6));
            if(heart==0){
                getWorld().addObject(new heart(),getX(),getY());
                getWorld().removeObject(this);
            }
        }
    }  
    
    public void checkM1()//ensures that the bat cannot clip through walls, overworld
    {
        if(isTouching(M1B1.class))
        {
            check++;
        }
        if(isTouching(M1B2.class))
        {
            check++;
        }
        if(isTouching(M1B3.class))
        {
            check++;
        }
        if(isTouching(M1B4.class))
        {
            check++;
        }
        if(isTouching(M1B5.class))
        {
            check++;
        }
        if(isTouching(M1B6.class))
        {
            check++;
        }
        if(isTouching(M1B7.class))
        {
            check++;
        }
    }
    
    public void checkM2()
    {
        if(isTouching(M2B1.class))
        {
            check++;
        }
        if(isTouching(M2B2.class))
        {
            check++;
        }
        if(isTouching(M2B3.class))
        {
            check++;
        }
        if(isTouching(M2B4.class))
        {
            check++;
        }
        if(isTouching(M2B5.class))
        {
            check++;
        }
        if(isTouching(M2B6.class))
        {
            check++;
        }
    }
    
    public void checkM3()
    {
        if(isTouching(M3B1.class))
        {
            check++;
        }
        if(isTouching(M3B2.class))
        {
            check++;
        }
        if(isTouching(M3B3.class))
        {
            check++;
        }
        if(isTouching(M3B4.class))
        {
            check++;
        }
        if(isTouching(M3B5.class))
        {
            check++;
        }
        if(isTouching(M3B6.class))
        {
            check++;
        }
        if(isTouching(M3B7.class))
        {
            check++;
        }
        if(isTouching(M3B8.class))
        {
            check++;
        }
    }
    
    public void checkM7()
    {
        if(isTouching(M7B1.class))
        {
            check++;
        }
    }
    
    public void checkM8()
    {
        if(isTouching(M8B1.class))
        {
            check++;
        }
        if(isTouching(M8B2.class))
        {
            check++;
        }
    }
    
    public void checkM9()
    {
        if(isTouching(M9B1.class))
        {
            check++;
        }
        if(isTouching(M9B2.class))
        {
            check++;
        }
        if(isTouching(M9B3.class))
        {
            check++;
        }
        if(isTouching(M9B4.class))
        {
            check++;
        }
        if(isTouching(M9B5.class))
        {
            check++;
        }
        if(isTouching(M9B6.class))
        {
            check++;
        }
        if(isTouching(M9B7.class))
        {
            check++;
        }
        if(isTouching(M9B9.class))
        {
            check++;
        }
        if(isTouching(M9B10.class))
        {
            check++;
        }
        if(isTouching(M9B11.class))
        {
            check++;
        }
    }
    
    public void checkM10()
    {
        if(isTouching(M10B1.class))
        {
            check++;
        }
        if(isTouching(M10B2.class))
        {
            check++;
        }
        if(isTouching(M10B3.class))
        {
            check++;
        }
        if(isTouching(M10B4.class))
        {
            check++;
        }
        if(isTouching(M10B5.class))
        {
            check++;
        }
        if(isTouching(M10B6.class))
        {
            check++;
        }
        if(isTouching(M10B7.class))
        {
            check++;
        }
    }
    
    public void checkD1()// checks so that it cannot clip thorugh the dungeons
    {
        if(isTouching(D1B1.class))
        {
            check++;
        }
        if(isTouching(D1B2.class))
        {
            check++;
        }
        if(isTouching(D1B3.class))
        {
            check++;
        }
        if(isTouching(D1B4.class))
        {
            check++;
        }
        if(isTouching(D1B5.class))
        {
            check++;
        }
        if(isTouching(D1B6.class))
        {
            check++;
        }
        if(isTouching(D1B7.class))
        {
            check++;
        }
        if(isTouching(D1B8.class))
        {
            check++;
        }
        if(isTouching(D1B9.class))
        {
            check++;
        }
        if(isTouching(D1B10.class))
        {
            check++;
        }
        if(isTouching(D1B11.class))
        {
            check++;
        }
        if(isTouching(D1B12.class))
        {
            check++;
        }
        if(isTouching(D1B13.class))
        {
            check++;
        }
        if(isTouching(D1B14.class))
        {
            check++;
        }
        if(isTouching(D1B15.class))
        {
            check++;
        }
        if(isTouching(D1B16.class))
        {
            check++;
        }
        if(isTouching(D1B17.class))
        {
            check++;
        }
        if(isTouching(D1B18.class))
        {
            check++;
        }
        if(isTouching(D1B19.class))
        {
            check++;
        }
        if(isTouching(D1B20.class))
        {
            check++;
        }
        if(isTouching(D1B21.class))
        {
            check++;
        }
        if(isTouching(D1B22.class))
        {
            check++;
        }
        if(isTouching(D1B23.class))
        {
            check++;
        }
    }
}
