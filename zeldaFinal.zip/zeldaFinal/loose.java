import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class loose here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class loose extends Actor
{
    /**
     * Act - do whatever the loose wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     *///260,244;
    public void act() 
    {
        // Add your action code here.
    }    
}
